'use server';

import { hasValidPendingVerification } from './verification';

// Re-export the function from the centralized verification module
export { hasValidPendingVerification };
