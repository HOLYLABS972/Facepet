import AuthPage from '@/src/components/auth/AuthPage';

export default function Auth() {
  return <AuthPage />;
}
