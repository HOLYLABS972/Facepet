import ForgotPasswordPage from '@/src/components/auth/ForgotPasswordPage';

export default function ForgotPassword() {
  return <ForgotPasswordPage />;
}
