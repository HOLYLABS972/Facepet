import ResetPasswordSentPage from '@/src/components/auth/ResetPasswordSentPage';

export default function ResetPasswordSent() {
  return <ResetPasswordSentPage />;
}
