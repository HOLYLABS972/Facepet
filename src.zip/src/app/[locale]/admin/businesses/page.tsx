'use client';

import BusinessesPage from '@/components/admin/BusinessesPage';

export default function AdminBusinessesPage() {
  return <BusinessesPage />;
}

