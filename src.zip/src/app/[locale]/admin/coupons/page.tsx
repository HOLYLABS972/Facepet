'use client';

import PromosPage from '@/components/admin/PromosPage';

export default function AdminCouponsPage() {
  return <PromosPage />;
}

