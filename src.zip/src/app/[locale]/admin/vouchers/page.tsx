'use client';

import CouponsPage from '@/components/admin/CouponsPage';

export default function AdminCouponsPage() {
  return <CouponsPage />;
}
