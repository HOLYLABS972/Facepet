import WelcomeGetStartedPage from '@/components/WelcomeGetStartedPage';

const WelcomePage = ({ params }: { params: { id: string } }) => {
  return <WelcomeGetStartedPage />;
};

export default WelcomePage;
