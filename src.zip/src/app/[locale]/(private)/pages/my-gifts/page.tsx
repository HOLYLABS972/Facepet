import MyGiftsPage from '@/src/components/user/MyGiftsPage';

const page = () => {
  return <MyGiftsPage pets={[]} />;
};

export default page;
