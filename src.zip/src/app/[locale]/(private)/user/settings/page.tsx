import SettingsPage from '@/src/components/user/SettingsPage';

const page = () => {
  return <SettingsPage />;
};

export default page;
