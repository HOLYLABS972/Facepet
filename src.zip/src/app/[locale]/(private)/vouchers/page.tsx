import UserCouponsPage from '@/components/user/UserCouponsPage';

export default function VouchersPage() {
  return <UserCouponsPage />;
}

