# Code Citations

## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </Dropdown
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <Dropdown
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() =>
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </Drop
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </Drop
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    
```


## License: unknown
https://github.com/zangue-mbcode/upply-test/blob/2a918dfaa71a291726be067ab996729a667b0e2c/components/features/layout/Header.tsx

```
>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </
```

