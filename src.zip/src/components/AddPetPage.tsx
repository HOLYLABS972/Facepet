import AddNewPetForm from './AddNewPetForm';

export default function AddPetPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <AddNewPetForm />
    </div>
  );
}